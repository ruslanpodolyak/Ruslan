<footer class="footer">
    <div class="footer-logo"><img src="<?php echo get_template_directory_uri();?> /img/footerlogo.png"></div>
    <div class="footer-contacts">
        <p>© 2016 Sat-servis</p>
        <h3>8 (495) 205-43-34</h3>
        <p>Москва, Цветной бульвар, д. 11,
            стр. 6, офис 406</p>
    </div>
       <div class="footer-nav">
        <ul>
            <li><a href="#">Главная</a></li>
            <li><a href="#">О компании</a></li>
            <li><a href="#">Наши услуги</a></li>
            <li><a href="#">Новости</a></li>
            <li><a href="#">Партнеры</a></li>
            <li><a href="#">Контакты</a></li>
        </ul>
    </div>
    <div class="social">
        <a href="#"><img src="<?php echo get_template_directory_uri();?> /img/VK.png"></a>
        <a href="#"><img src="<?php echo get_template_directory_uri();?> /img/stat.png"></a>
        <div class="clearfix"></div>
        <p>Design Studio Copyrights</p>
    </div>
</footer>

</div>
<?php wp_footer(); ?>
</body>
</html>