<?php get_header() ?>
    <nav class="navigation">
        <span><a href="#"><img src="<?php echo get_template_directory_uri();?> /img/home.png"></a></span>
        <div class="nav-menu">
            <a href="#">О нас</a>
            <a href="#">Наши работы</a>
            <a href="#">Гарантийные обязательства</a>
            <a href="#">Оплата</a>
            <a href="#">Контакты</a>
            <a href="#">Вакансии</a>
        </div>
    </nav>
        <aside class="sidebar">
            <div class="menu">
                <p>Профессионально выполним:</p>
                <ul>
                    <li><a href="#">Установка спутникового ТВ</a></li>
                    <li><a href="#">Установка эфирного ТВ</a></li>
                    <li><a href="#">Подключение коллективного ТВ</a></li>
                    <li><a href="#">Спроектируем на этапе
                        строительства</a></li>
                    <li><a href="#">Диагностика</a></li>
                    <li><a href="#">Закрепим на стене</a></li>
                    <li><a href="#">Монтаж ТВ-розеток</a></li>
                    <li><a href="#">Ремонт антенн</a></li>
                    <li><a href="#">Прокладка кабеля</a></li>
                    <li><a href="#">Переделаем аналоговое ТВ в
                        цифровое</a></li>
                    <li><a href="#">Монтаж комплексного ТВ</a></li>
                    <li><a href="#">Спутниковый интернет</a></li>
                    <li><a href="#">Подключение FM-антенн</a></li>
                    <li><a href="#">Подбор оптимального
                        оборудования</a></li>
                    <li><a href="#">Усиление слабого сигнала</a></li>
                </ul>
            </div>
            <div class="button-left">
                <div class="red-button">
                    <a href="#">
                        <p>Акции, скидки и спецпредложения</p>
                        <span><img src="<?php echo get_template_directory_uri();?> /img/redbut.png"></span>
                    </a>
                </div>
                <div class="blue-button">
                    <a href="#">
                        <p>Отзывы о нас</p>
                        <span><img src="<?php echo get_template_directory_uri();?> /img/bluebut.png"></span>
                    </a>
                </div>
            </div>
            <div class="our-preim">
                <h2>Наши преимущества</h2>
                <p>В данном блоке Вы сможете перечислить ряд преимуществ Вашей компании и т.п.
                    информации. Блок наполнен тестовой информацией для наглядности.</p>
            </div>
            <div class="sertif">
                <img src="<?php echo get_template_directory_uri();?> /img/sertif1.jpg"><img src="<?php echo get_template_directory_uri();?> /img/sertif2.jpg">
            </div>
            <div class="news">
                <div class="top-news"><h2>Новости</h2> <a href="#"><p>Все новости</p></a></div>
                <div class="last-news">
                    <p>23.05.16</p>
                    <a href="#">Примерный текст наполнения новостной ленты предоставлен для наглядности.</a>
                    <p>18.05.16</p>
                    <a href="#">Данный текст Вы сможете редактировать через систему управления сайтом.</a>
                </div>
            </div>
        </aside>
        <div class="content">
            <div class="spuTV">
                <h2>Эфирное ТВ</h2>
                <table>
                    <tr><td><a href="#"><img src="<?php echo get_template_directory_uri();?> /img/spuTV15.jpg"></a></td><td colspan="2"><a href="#"><img src="<?php echo get_template_directory_uri();?> /img/spuTV11.jpg"></a></td><td><a href="#"><img src="<?php echo get_template_directory_uri();?> /img/spuTV5.jpg"></a></td></tr>
                    <tr><td><a href="#"><img src="<?php echo get_template_directory_uri();?> /img/spuTV14.png"></a></td><td colspan="2"><a href="#"><img src="<?php echo get_template_directory_uri();?> /img/spuTV3.jpg"></a></td><td><a href="#"><img src="<?php echo get_template_directory_uri();?> /img/spuTV4.png"></a></td></tr>
                    <tr><td><a href="#"><img src="<?php echo get_template_directory_uri();?> /img/spuTV13.jpg"></a></td><td><a href="#"><img src="<?php echo get_template_directory_uri();?> /img/spuTV9.png"></a></td><td><a href="#"><img src="<?php echo get_template_directory_uri();?> /img/spuTV6.jpg"></a></td><td><a href="#"><img src="<?php echo get_template_directory_uri();?> /img/sputTV1.jpg"></a></td></tr>
                    <tr><td><a href="#"><img src="<?php echo get_template_directory_uri();?> /img/spuTV10.png"></a></td><td><a href="#"><img src="<?php echo get_template_directory_uri();?> /img/spuTV8.png"></a></td><td><a href="#"><img src="<?php echo get_template_directory_uri();?> /img/spuTV7.png"></a></td><td><a href="#"><img src="<?php echo get_template_directory_uri();?> /img/spuTV2.jpg"></a></td></tr>
                </table>
            </div>
            <div class="efirTV">
                <h2>Эфирное ТВ</h2>
                <div class="efirtv-TV1"><a href="#"><img src="<?php echo get_template_directory_uri();?> /img/TV1.jpg"></a></div>
                <div class="efirtv-TV2"><a href="#"><img src="<?php echo get_template_directory_uri();?> /img/TV2.jpg"></a></div>
            </div>
            <div class="komplTV">
                <h2>Комплексное ТВ</h2>
                <div class="house"><a href="#"><img src="<?php echo get_template_directory_uri();?> /img/house.jpg"></a></div>
            </div>
        </div>
        <div class="clearfix"></div>

 <?php get_footer() ?>