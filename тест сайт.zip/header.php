<!DOCTYPE html>
<html>
<head lang="ru">
    <meta charset="UTF-8">
    <title>Сайт</title>
    <?php wp_head(); ?>
</head>
<body>
<div class="wrap">
    <header class="header">
        <div class="logo">
            <div class="header-logo">
                <a href="#"><img src="<?php echo get_template_directory_uri();?> /img/Logo.png" width="220px" height="60px"></a>
                <h1>качественное телевидение доступно каждому</h1>
            </div>
            <div class="header-zvonite">
                <p>8 (495) 205-43-34<br>
                    <span>с 8:00 до 22:00, без выходных</span>
                </p>
                <p>8 (926) 021-43-34<br>
                    <span>Техподдержка, круглостуочно</span>
                </p>
                <div class="zvonok">
                    <div class="phone"><img src="<?php echo get_template_directory_uri();?> /img/phone.png"></div>
                    <div class="zakaz"><p>Заказать звонок</p><img src="<?php echo get_template_directory_uri();?> /img/down.png"></div>
                </div>
            </div>

        </div>
    </header>